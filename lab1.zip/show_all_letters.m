function show_all_letters
% SHOW_ALL_LETTERS and SHOW_ALL_FACES - display all the appropriate
%   images as a set of 'thumbnail' sketches.
%
%   See also SHOW, LETTER, FACE.

global MAXPICNUM bnw

% The parameters for the (invisible) grid of images to be displayed.
X = 5;
Y = 4;

for P=1:MAXPICNUM
	subplot(Y,X,P);
	image(letter(P)*255)
	axis image
	axis off
	colormap(bnw)
	title(sprintf('Letter %d', P));
end
