function img = letter(num)
% LETTER and FACE - Easy access to picture database
%   Calling one of these functions with the picture number required
%   as argument returns the image, e.g.:
%
%      s = letter(9)
%      show(s)
%
%      evaluate(face(4))
%
%   See also SHOW, EVALUATE.

global pic LETTER

img = pic(:,:,num,LETTER);

