function show(img)
% SHOW(image) - Displays a picture from memory
%   Use with the LETTER and FACE functions, e.g:
%
%      show(letter(9))
%      show(face(3))
%
%   See also LETTER, FACE.

global bnw

subplot(1,1,1)
image(img*255)
axis image
axis off
colormap(bnw)


