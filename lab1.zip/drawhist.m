function drawhist(f_results,l_results,nbins)
% DRAWHIST - Draws a histogram based on EVALUATE function
%   Call DRAWHIST with the results from EVALUATE_RANGE to
%   produce a histogram of them.  The third, optional argument
%   is the number of bins in the histogram (default = 10).
%   For greater flexibility, use the inbuilt function HIST.
%   Usage, e.g.:
%
%     
%      [f_results l_results] = evaluate_range([1 2 3 5 8 13],ALL)
%      drawhist(f_results,r_results,8)
%
%   See also EVALUATE, EVALUATE_RANGE, HIST.


% Modified by Jonathan Shapiro, Oct 6, 1998. 
global grey

% Set default for parameter if not given
if nargin<3 nbins=10; end

% Calculate the bin boundaries
min_val = min([f_results l_results]);
max_val = max([f_results l_results]);
bins = min_val:(max_val-min_val)/(nbins-1):max_val;

% stacks will store the combined histogram data
stacks = zeros(nbins,3);

% Use hist to calculate stack data

if isempty(f_results)
	fprintf(1,'Warning: no face data.\n');
else
	[N1,X] = hist(f_results,bins);
	stacks(:,2) = N1';
end

if isempty(l_results)
	fprintf(1,'Warning: no letter data.\n');
else
	[N2,X] = hist(l_results,bins);
	stacks(:,3) = N2';
end

% Calculate intersections between the two histograms
for row=1:size(stacks,1)
	mn = min(stacks(row,2),stacks(row,3));
	stacks(row,1)=mn;
	stacks(row,2)=stacks(row,2)-mn;
	stacks(row,3)=stacks(row,3)-mn;
end

% Draw the graph and add some labels
subplot(1,1,1);
handles = bar(X,stacks,1,'stack');
half_width_of_bin = (max_val-min_val)/(2*(nbins-1));
set(gca, 'XTick', [floor(bins(1)-half_width_of_bin), ...
	 floor(bins+half_width_of_bin)]);
title('Histogram showing results of ''evaluate'' on all pictures');
xlabel('Value returned by ''evaluate''');
ylabel('Frequency');
legend([handles(2),handles(3),handles(1)], ...
	['Faces  ';'Letters';'Both   ']);
colormap(grey);
grid on;
