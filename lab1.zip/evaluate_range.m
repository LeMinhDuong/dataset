function [f_results, l_results] = evaluate_range(facerange, letterrange)
% EVALUATE_RANGE(facerange [, letterrange]) - Evaluates a range of images.
%   EVALUATE_RANGE will iteratively apply your EVALUATE function
%   to the range supplied.  Specify two ranges when calling, the
%   first the range of faces, the second the range of letters you
%   wish to evaluate.  (If only one range is given, it will be
%   used for both faces AND letters.)  Returns two matrices containing the 
%   results.
%   Usage, e.g.:
%
%      evaluate_range([1 2 5 7 9 11 12 17], 1:6) - calls EVALUATE for
%                             eight faces and the first six letters.
%      evaluate_range(1:9); - calls EVALUATE for the first nine
%                             letters and numbers.
%      [faces_result letters_results] = evaluate_range(ALL); - calls EVALUATE 
%                          for all of them, storing answer in the two matrices.
%
%   See also EVALUATE, DRAWHIST, FORMAT_RESULTS.

% Modified by Jonathan Shapiro, Oct 6, 1998.


global pic FACE LETTER

% Set letterrange to be the same as facerange if not supplied
if nargin<2, letterrange = facerange; end

% Initialize the results matrix
f_results = zeros(size(facerange));
l_results = zeros(size(letterrange));

row=1;

% Evaluate the faces
for i=facerange;
	fprintf(1,'Evaluating face %d...',i);
	
	f_results(row) = evaluate(face(i));
	fprintf(1,' %d\n',f_results(row));
	row = row + 1;
end

row=1;
% Evaluate the letters
for i=letterrange;
	fprintf(1,'Evaluating letter %d...',i);
	l_results(row) = evaluate(letter(i));
	fprintf(1,' %d\n',l_results(row));
	row = row + 1;
end
