% STARTLAB1 - The initialization script for CS2411 Lab 1.
%   Use this command just after starting MatLab, to initialize
%   various things needed in Lab 1.  Specifically, it loads and
%   sets some global variables that are necessary.  You should
%   only need to know about one of them, ALL - this is a range
%   set up to include all the image numbers (which is 1:18)

% The picture data

load pic.mat


% Define global constants for ease of indexing pic array

global FACE LETTER MAXPICNUM

FACE = 1;
LETTER = 2;
MAXPICNUM = size(pic,3);


% Define constant ALL

global ALL

ALL = [1:MAXPICNUM];


% Colourmaps used

global bnw grey

bnw = [1 1 1; 0 0 0];
grey = [.5 .5 .5; 1 1 1; 0 0 0];